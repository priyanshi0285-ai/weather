from tkinter import *
import tkinter as tk
from geopy.geocoders import Nominatim
from tkinter import ttk, messagebox
from timezonefinder import TimezoneFinder
from datetime import datetime, timedelta
import requests
import pytz
from PIL import Image, ImageTk
import os

root = Tk()
root.title("Weather App")
root.geometry("890x470+300+200")
root.configure(bg="lightblue")
root.resizable(False, False)

# Helper function to handle icon loading safely
def update_icon(label_obj, icon_code):
    icon_name = f"{icon_code}@2x.png"
    # Search in multiple common project structures
    search_paths = [
        os.path.join("icon", icon_name),
        os.path.join("Images", "icon", icon_name),
        os.path.join("project", "wheater", "icon", icon_name),
        icon_name 
    ]
    
    found = False
    for path in search_paths:
        if os.path.exists(path):
            try:
                img = Image.open(path).resize((50, 50))
                photo = ImageTk.PhotoImage(img)
                label_obj.config(image=photo, text="")
                label_obj.image = photo
                found = True
                break
            except:
                continue
    
    if not found:
        label_obj.config(text=icon_code, fg="white", font=("arial", 10))

def getWeather():
    city = textfield.get()

    # 1. Geolocation
    geolocator = Nominatim(user_agent="geoExercises")
    try:
        location = geolocator.geocode(city)
    except:
        messagebox.showerror("Error", "Geocoding service down")
        return

    if location is None:
        messagebox.showerror("Error", "City not found")
        return

    # 2. Timezone & Clock
    obj = TimezoneFinder()
    result = obj.timezone_at(lng=location.longitude, lat=location.latitude)
    timezone.config(text=result)
    long_lat.config(text=f"{round(location.latitude,4)}°N, {round(location.longitude,4)}°E")
    
    home = pytz.timezone(result)
    local_time = datetime.now(home)
    clock.config(text=local_time.strftime("%I:%M %p"))

    # 3. API Call (Free 5-Day/3-Hour Forecast)
    api_key = "a8ee932668151cf248004935b2687431"
    api = f"https://api.openweathermap.org/data/2.5/forecast?lat={location.latitude}&lon={location.longitude}&units=metric&appid={api_key}"
    
    try:
        json_data = requests.get(api).json()
        if json_data.get("cod") != "200":
            messagebox.showerror("API Error", json_data.get("message"))
            return
    except:
        messagebox.showerror("Error", "Check Internet Connection")
        return

    # 4. Update Main Stats (Top Left Box)
    current_item = json_data['list'][0]
    t.config(text=f"{current_item['main']['temp']}°C")
    h.config(text=f"{current_item['main']['humidity']}%")
    p.config(text=f"{current_item['main']['pressure']}hPa")
    w.config(text=f"{current_item['wind']['speed']}m/s")
    d.config(text=current_item['weather'][0]['description'])

    # 5. Update First Bottom Cell (Day & Night Temp)
    # Scan first 8 entries (24 hours) for High/Low
    first_24h = json_data['list'][:8]
    day_high = max(item['main']['temp_max'] for item in first_24h)
    night_low = min(item['main']['temp_min'] for item in first_24h)
    
    day1.config(text=local_time.strftime("%A"))
    day1temp.config(text=f"Day: {round(day_high)}°C\nNight: {round(night_low)}°C")
    update_icon(firstimage, current_item['weather'][0]['icon'])

    # 6. Update Remaining 6 Cells
    image_labels = [secondimage, thirdimage, fourthimage, fifthimage, sixthimage, seventhimage]
    temp_labels = [day2temp, day3temp, day4temp, day5temp, day6temp, day7temp]
    day_labels = [day2, day3, day4, day5, day6, day7]
    
    # Indices roughly 24 hours apart starting from the next day
    forecast_indices = [8, 16, 24, 32, 38, 39] 

    for i in range(6):
        try:
            data = json_data['list'][forecast_indices[i]]
            future_day = local_time + timedelta(days=i+1)
            day_labels[i].config(text=future_day.strftime("%a"))
            temp_labels[i].config(text=f"{round(data['main']['temp'])}°C")
            update_icon(image_labels[i], data['weather'][0]['icon'])
        except Exception as e:
            print(f"Error in cell {i+2}: {e}")

# --- UI ELEMENTS ---
# App Icon
try:
    image_icon = PhotoImage(file="Images/logo.png")
    root.iconphoto(False, image_icon)
except:
    pass

# Current Weather Detail Box
Round_box = PhotoImage(file="Images/Rounded Rectangle 1.png")
Label(root, image=Round_box, bg="lightblue").place(x=30, y=110)

Label(root, text="Temperature", font=('Helvetica', 11), fg="white", bg="#203243").place(x=50, y=120)
Label(root, text="Humidity", font=('Helvetica', 11), fg="white", bg="#203243").place(x=50, y=140)
Label(root, text="Pressure", font=('Helvetica', 11), fg="white", bg="#203243").place(x=50, y=160)
Label(root, text="Wind Speed", font=('Helvetica', 11), fg="white", bg="#203243").place(x=50, y=180)
Label(root, text="Description", font=('Helvetica', 11), fg="white", bg="#203243").place(x=50, y=200)

# Search Bar
search_image = PhotoImage(file="Images/Rounded Rectangle 3.png")
Label(image=search_image, bg="lightblue").place(x=270, y=120)
weat_image = PhotoImage(file="Images/Layer 7.png")
Label(root, image=weat_image, bg="#203243").place(x=290, y=127)

textfield = Entry(root, justify='center', width=15, font=('poppins', 15, 'bold'), bg="#203243", border=0, fg="white")
textfield.place(x=370, y=135)
textfield.focus()

search_icon = PhotoImage(file="Images/Layer 6.png")
Button(image=search_icon, borderwidth=0, cursor="hand2", bg="#203243", command=getWeather).place(x=645, y=125)

# Bottom Decoration
frame = Frame(root, width=900, height=180, bg="#203243")
frame.pack(side=BOTTOM)

# Decorative Boxes
firstbox = PhotoImage(file="Images/Rounded Rectangle 2.png")
secondbox = PhotoImage(file="Images/Rounded Rectangle 2 copy.png")
Label(frame, image=firstbox, bg="#203243").place(x=30, y=20)
for x in [300, 400, 500, 600, 700, 800]:
    Label(frame, image=secondbox, bg="#203243").place(x=x, y=30)

# Main Output Labels
clock = Label(root, font=("Helvetica", 30, 'bold'), fg="white", bg="lightblue")
clock.place(x=30, y=20)
timezone = Label(root, font=("Helvetica", 20), fg="white", bg="lightblue")
timezone.place(x=600, y=20)
long_lat = Label(root, font=("Helvetica", 10), fg="white", bg="lightblue")
long_lat.place(x=600, y=55)

t = Label(root, font=("Helvetica", 11), fg="white", bg="#203243")
t.place(x=150, y=120)
h = Label(root, font=("Helvetica", 11), fg="white", bg="#203243")
h.place(x=150, y=140)
p = Label(root, font=("Helvetica", 11), fg="white", bg="#203243")
p.place(x=150, y=160)
w = Label(root, font=("Helvetica", 11), fg="white", bg="#203243")
w.place(x=150, y=180)
d = Label(root, font=("Helvetica", 11), fg="white", bg="#203243")
d.place(x=150, y=200)

# --- Bottom Cell Layouts ---
# Frame 1 (Big)
firstframe = Frame(root, width=230, height=132, bg="#282829")
firstframe.place(x=35, y=315)
day1 = Label(firstframe, font="arial 20", bg="#282829", fg="#fff")
day1.place(x=100, y=5)
firstimage = Label(firstframe, bg="#282829")
firstimage.place(x=1, y=15)
day1temp = Label(firstframe, bg="#282829", fg="#57adff", font="arial 11 bold", justify="left")
day1temp.place(x=100, y=50)

# Frame Helper
def make_cell(x_pos):
    f = Frame(root, width=70, height=115, bg="#282829")
    f.place(x=x_pos, y=325)
    d_lbl = Label(f, font="arial 10", bg="#282829", fg="#fff")
    d_lbl.place(x=5, y=5)
    i_lbl = Label(f, bg="#282829")
    i_lbl.place(x=7, y=25)
    t_lbl = Label(f, bg="#282829", fg="#fff", font="arial 9 bold")
    t_lbl.place(x=2, y=80)
    return d_lbl, i_lbl, t_lbl

day2, secondimage, day2temp = make_cell(305)
day3, thirdimage, day3temp = make_cell(405)
day4, fourthimage, day4temp = make_cell(505)
day5, fifthimage, day5temp = make_cell(605)
day6, sixthimage, day6temp = make_cell(705)
day7, seventhimage, day7temp = make_cell(805)

root.mainloop()
